
version number/string is in simlib.h

